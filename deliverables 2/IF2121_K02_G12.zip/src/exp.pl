
job(1, 'Fisherman').
job(2, 'Farmer').
job(3, 'Rancher').


levelCap(1, 300).
levelCap(2, 500).
levelCap(3, 1000).