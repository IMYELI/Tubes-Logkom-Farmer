marketSpring :-
    nl,
    write('===============Marketplace==============='), nl,
    write('          What do you want to buy?       '), nl,
    write('========================================='), nl,
    write('     1. Corn seed (50 golds)             '), nl,
    write('     2. Chicken (500 golds)              '), nl,
    write('     3. Sheep (1000 golds)               '), nl,
    write('     4. Cow (1500 golds)                 '), nl,
    write('     5. Level 2 shovel (300 golds)       '), nl,
    write('     6. Level 2 Fishing rod (500 golds)  '), nl,
    write('-----------------------------------------'), nl.

marketSummer :-
    nl,
    write('===============Marketplace==============='), nl,
    write('          What do you want to buy?       '), nl,
    write('========================================='), nl,
    write('     1. Tomato seed (50 golds)           '), nl,
    write('     2. Chicken (500 golds)              '), nl,
    write('     3. Sheep (1000 golds)               '), nl,
    write('     4. Cow (1500 golds)                 '), nl,
    write('     5. Level 2 shovel (300 golds)       '), nl,
    write('     6. Level 2 Fishing rod (500 golds)  '), nl,
    write('-----------------------------------------'), nl.

marketFall :-
    nl,
    write('===============Marketplace==============='), nl,
    write('          What do you want to buy?       '), nl,
    write('========================================='), nl,
    write('     1. Potato seed (50 golds)           '), nl,
    write('     2. Chicken (500 golds)              '), nl,
    write('     3. Sheep (1000 golds)               '), nl,
    write('     4. Cow (1500 golds)                 '), nl,
    write('     5. Level 2 shovel (300 golds)       '), nl,
    write('     6. Level 2 Fishing rod (500 golds)  '), nl,
    write('-----------------------------------------'), nl.

marketWinter :-
    nl,
    write('===============Marketplace==============='), nl,
    write('          What do you want to buy?       '), nl,
    write('========================================='), nl,
    write('     1. Carrot seed (50 golds)           '), nl,
    write('     2. Chicken (500 golds)              '), nl,
    write('     3. Sheep (1000 golds)               '), nl,
    write('     4. Cow (1500 golds)                 '), nl,
    write('     5. Level 2 shovel (300 golds)       '), nl,
    write('     6. Level 2 Fishing rod (500 golds)  '), nl,
    write('-----------------------------------------'), nl.
    




