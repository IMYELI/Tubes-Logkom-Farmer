startGame :-
    ['main.pl'],
    title, 
    mainMenu.