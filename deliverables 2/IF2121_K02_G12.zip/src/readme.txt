Deliverable 2 
Kelompok 12
Kelas 2

Untuk menjalankan program file ini, silahkan buka program GNU prolog dan dari menu file pilih
'change directory' lalu pindahkan ke direktori tempat kamu mengestrak file prolog.
Dari menu file pilih consult lalu pilih driver.pl.
Ketik command 'startGame.' untuk memulai game.
